from login import *

from tkinter import *

login = Tk()
login_screen(login)

login.mainloop()